# Hanzi — Brand Guide

*--- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---*

--- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---

Extracted from designmd://hanzi.

## Color roles

- **Paper: "** (`#fafbfa`) — background: page canvas
- **Ink: "** (`#1f2a27`) — foreground: body text and headings
- **Accent secondary   Vermilion    #d24b3f    attention, errors, milestones and exam moments only — amber owns streaks  vermilion 600 / brandAccent; small error text uses vermilion 700** (`#a9342b`) — accent: primary actions and emphasis
- **Surface** (`#f1f3f2`) — surface: cards and panels
- **Slate: "** (`#66756f`) — muted: secondary text and metadata
- **Line: "** (`#e8ecea`) — border: rules and dividers

## Typography

- Display: SFMono
- Body: SFMono
- Mono: SFMono

## Messaging pillars

- --- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---
