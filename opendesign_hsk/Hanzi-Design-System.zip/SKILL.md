---
name: hanzi
description: Use this skill when generating OpenDesign artifacts that should follow Hanzi.
user-invocable: true
---

Read README.md, DESIGN.md, colors_and_type.css, preview/, preserved assets, context evidence, and ui_kits/app/ before generating any new interface.

**What's inside:**
- DESIGN.md as the canonical source-backed rules document.
- colors_and_type.css as the reusable token stylesheet.
- preview/ focused review cards for color, typography, spacing, components, and brand assets.
- ui_kits/app/ as a browser-reviewable applied interface kit with modular role components.
- context/ provenance and evidence notes for future refreshes.

**Source context:**
*--- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---*

**When to use this skill:**
- Creating product-like prototypes that should follow Hanzi.
- Revising focused design-system preview cards or app UI kit components.
- Building interfaces that need this package's captured density, hierarchy, tokens, and anti-patterns.

**How to use:**
1. Read DESIGN.md for product context, foundations, components, motion, voice, and anti-patterns.
2. Load colors_and_type.css instead of hardcoding palette, typography, radius, or spacing values.
3. Inspect preview/ cards for focused modules before inventing new styling.
4. Reuse ui_kits/app/index.html and ui_kits/app/components/ as the applied component composition.
5. Preserve the product context, hierarchy, density, and anti-patterns documented in DESIGN.md.

**Design system highlights:**

- Background: #fafbfa
- Foreground: #1f2a27
- Accent: #d24b3f
- Border: #e8ecea
