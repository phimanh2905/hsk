# Hanzi

A reusable OpenDesign package for Hanzi.

## Product Overview

*--- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---* This design-system package is designed for product, app, workspace, and platform surfaces that need a reusable visual direction rather than a one-off mockup. It provides a concrete token layer, focused preview cards, and an applied UI kit so future agents can build interfaces with the same hierarchy, density, component roles, and interaction rules captured in DESIGN.md.

## Package Overview

- Category: Brands
- Surface: web
- Primary accent: #d24b3f
- Background: #fafbfa
- Foreground: #1f2a27

## Captured Foundations

- Color Palette
- Typography
- Voice & Tone
- Imagery
- Layout

## Generated Files

- DESIGN.md: canonical design system source.
- colors_and_type.css: reusable CSS variables for color and type.
- preview/: focused HTML review cards for color themes, typography, spacing, components, and brand assets.
- assets/: logo and brand asset references.
- context/: structured source context captured during setup.
- ui_kits/app/: applied interface preview and UI-kit notes.
- SKILL.md: agent-facing usage instructions.

