---
name: "Hanzi"
category: Brands
surface: web
colors:
  paper: "#fafbfa"
  ink: "#1f2a27"
  accent-secondary-vermilion-d24b3f-attention-errors-milestones-and-exam-moments-only-amber-owns-streaks-vermilion-600-brandaccent-small-error-text-uses-vermilion-700: "#a9342b"
  surface: "#f1f3f2"
  slate: "#66756f"
  line: "#e8ecea"
---

# Hanzi

> Category: Brands

> Surface: web

*--- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---*

--- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---

## Color Palette

| Role | Name | Hex | Usage |
| --- | --- | --- | --- |
| background | Paper: " | `#fafbfa` | page canvas |
| foreground | Ink: " | `#1f2a27` | body text and headings |
| accent | Accent secondary   Vermilion    #d24b3f    attention, errors, milestones and exam moments only — amber owns streaks  vermilion 600 / brandAccent; small error text uses vermilion 700 | `#a9342b` | primary actions and emphasis |
| surface | Surface | `#f1f3f2` | cards and panels |
| muted | Slate: " | `#66756f` | secondary text and metadata |
| border | Line: " | `#e8ecea` | rules and dividers |

## Typography
- **Display:** SFMono — weights 400, 700 — fallbacks: system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif
- **Body:** SFMono — weights 400, 700 — fallbacks: system-ui, -apple-system, Segoe UI, Helvetica Neue, Arial, sans-serif
- **Mono:** SFMono — weights 400, 700 — fallbacks: ui-monospace, SFMono-Regular, Menlo, monospace

## Voice & Tone

- **Adjectives:** (none yet)
- **Tone:** --- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---

### Messaging pillars
- --- name: "Hanzi" category: Brands surface: web colors: paper: "#fafbfa" elevated: "#ffffff" ink: "#1f2a27" slate: "#66756f" line: "#e8ecea" jade: "#0f766e" vermilion: "#d24b3f" ---

### Vocabulary
- **Use:** (none yet)
- **Avoid:** (none yet)

## Imagery

- **Style:** (none yet)
- **Subjects:** (none yet)
- **Treatment:** (none yet)
- **Avoid:** (none yet)

## Layout

- **Radius:** 8px
- **Border weight:** 1px
- **Spacing:** 8px baseline grid

### Posture rules
- (none)
